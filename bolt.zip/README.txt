Bolt is a powerful video player for Wordpress!

Installation:

	1. Open the Wordpress Admin area and go to "Plugins > Add New", and click on "Upload Plugin"
	2. Open "bolt.zip" at the page

Usage:

	To show a video, you just need to use the "bolt_video_player" shortcode in your post or your page (you can add multiple video formats at the same time):
	"[bolt_video_player mp4="mp4 file"]"

	If you want to set the width and the height of the video, use the width and the height options:
	"[bolt_video_player mp4="mp4 file" width=""e.g. 340, 380, 50%" height="e.g. 600, 700, 50%"]"

	If you need to add webm and ogg videos, use the webm and the ogg options:
	"[bolt_video_player webm="webm file" ogg="ogg file"]"

Supported Video Formats:

	mp4, webm, ogg

Contact Me

	My Email Address: "bluesky42624@gmail.com"
	My Website: "http://www.IdeaAcademy.com/"


